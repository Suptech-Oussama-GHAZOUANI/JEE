package jee.suptech;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Todo1Application {

	public static void main(String[] args) {
		SpringApplication.run(Todo1Application.class, args);
	}

}
