package controllers;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/arbitres")
public class ArbitreController {
    
}
